class_name YinEnemy
extends CharacterBody2D
var game: Node2D
var record: Dictionary
var stun: float = 0
var cooldown: float = 1
var windup: float = 0
var attack_center := Vector2.ZERO
var hit_flash: float = 0
var hit_stop: float = 0
var health_trail: float = -1
var trail_delay: float = 0
var knockback := Vector2.ZERO
var burst_remaining: int = 0
var burst_timer: float = 0
var route: PackedVector2Array = []
var repath: float = 0
var victim: Node2D
var bleed_time: float = 0
var bleed_tick: float = 0
var bleed_damage: int = 0
var passive_clock: float = 0
var shield: int = 0
var charge_time: float = 0
var charge_direction: Vector2
var charge_hit: bool = false
var health_receiver: YinHealthReceiver
var hurtbox: YinHurtbox
const TEXTURE = preload("res://assets/enemies.png")

func _ready() -> void:
	var flash_material := ShaderMaterial.new()
	flash_material.shader = preload("res://shaders/hit_flash.gdshader")
	material = flash_material
	health_receiver = YinHealthReceiver.new()
	health_receiver.name = "HealthReceiver"
	health_receiver.bind_record(record)
	add_child(health_receiver)
	hurtbox = YinHurtbox.new()
	hurtbox.name = "Hurtbox"
	hurtbox.actor = self
	add_child(hurtbox)
	health_trail = float(record.hp)
	shield = 20 if record.kind == "opera_boss" else 0
	collision_layer = 4
	collision_mask = 7
	var shape := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = Vector2(14, 10)
	shape.shape = box
	shape.position.y = -4
	add_child(shape)

func _physics_process(delta: float) -> void:
	if game.modal != null or record.dead or is_queued_for_deletion(): return
	hit_flash = maxf(0, hit_flash - delta)
	material.set_shader_parameter("flash", 1.0 if hit_flash > 0.065 else 0.0)
	trail_delay = maxf(0, trail_delay - delta)
	if trail_delay <= 0: health_trail = move_toward(health_trail, float(record.hp), delta * record.max_hp)
	queue_redraw()
	if hit_stop > 0:
		hit_stop -= delta
		return
	var active_world: Node2D = game.world
	victim = game.closest_ally(position)
	if victim == null: return
	passive_clock += delta
	if bleed_time > 0:
		bleed_time -= delta
		bleed_tick -= delta
		if bleed_tick <= 0:
			bleed_tick = 1
			receive_hit(bleed_damage, "bleed")
			if record.dead: return
	if passive_clock >= 1:
		if record.kind == "water" and record.hp < record.max_hp / 2: record.hp = mini(record.max_hp, record.hp + 1)
		if record.kind == "opera_boss" and passive_clock >= 10:
			shield = 20
			passive_clock = 0
		elif record.kind != "opera_boss": passive_clock = 0
	stun = maxf(0, stun - delta)
	cooldown = maxf(0, cooldown - delta)
	var spec: Dictionary = YinBalance.MONSTERS[record.kind].duplicate()
	spec.pattern = YinAbilities.meta(record.kind).pattern
	if "leg" in record.get("severed", []): spec.speed *= 0.62
	var boss: bool = record.kind in YinAbilities.BOSSES
	var ranged: bool = spec.pattern in ["fan", "ring", "burst", "tide", "opera", "cold"]
	var distance: float = position.distance_to(victim.position)
	var sight_ray := PhysicsRayQueryParameters2D.create(position + Vector2(0, -4), victim.position + Vector2(0, -4), 1)
	var has_sight: bool = get_world_2d().direct_space_state.intersect_ray(sight_ray).is_empty()
	repath -= delta
	if charge_time > 0:
		charge_time -= delta
		velocity = charge_direction * (130 if "leg" in record.get("severed", []) else 210)
		if not charge_hit and position.distance_to(victim.position) < 32:
			hurt_victim(int(record.get("damage", spec.damage)))
			charge_hit = true
	elif stun > 0:
		windup = 0
		velocity = knockback
		knockback = knockback.move_toward(Vector2.ZERO, delta * 220)
	elif windup > 0:
		windup -= delta
		velocity = Vector2.ZERO
		if windup <= 0:
			if spec.pattern == "charge":
				charge_time = 0.45
				charge_direction = position.direction_to(attack_center)
				charge_hit = false
			elif ranged:
				volley(spec.pattern)
			elif victim.position.distance_to(attack_center) < (57 if boss else (42 if record.kind == "brute" else 29)):
				var ray := PhysicsRayQueryParameters2D.create(position + Vector2(0, -4), victim.position + Vector2(0, -4), 1)
				if get_world_2d().direct_space_state.intersect_ray(ray).is_empty(): hurt_victim(int(record.get("damage", spec.damage)))
			if record.kind == "boss": volley("boss")
			game.world.effect(attack_center, Color("b77862"))
			cooldown = (1.1 if boss and record.hp < record.max_hp / 2 else 2.2) if ranged else (1.5 if boss else 1.8)
			if record.kind == "gunner": cooldown *= 0.8
	elif burst_remaining > 0:
		velocity = Vector2.ZERO
		burst_timer -= delta
		if burst_timer <= 0:
			fire_bullet(position.direction_to(victim.position), 240)
			burst_remaining -= 1
			burst_timer = 0.16
	elif distance < (520 if ranged else (360 if game.state.minutes >= 1080 else 180)):
		var direction: Vector2 = position.direction_to(victim.position)
		velocity = direction * spec.speed * (1.35 if record.kind == "brute" and record.hp < record.max_hp / 2 else 1.0)
		if ranged:
			velocity = -direction * spec.speed if distance < 125 else (Vector2.ZERO if distance < 300 else velocity)
		if not has_sight:
			if repath <= 0:
				route = game.world.path_to(position, victim.position)
				repath = 0.5
			while route.size() > 0 and position.distance_to(route[0]) < 8: route.remove_at(0)
			velocity = position.direction_to(route[0]) * spec.speed if route.size() > 0 else velocity
		if has_sight and distance < (360 if ranged else (320 if boss else (210 if record.kind == "brute" else (42 if record.kind == "bone" else 26)))) and cooldown <= 0:
			windup = 0.85 if ranged else (0.8 if boss else 0.5)
			attack_center = victim.position
	else: velocity = Vector2.ZERO
	if game.world != active_world or not is_inside_tree(): return
	move_and_slide()
	record.at = [position.x, position.y]
	queue_redraw()
func fire_bullet(direction: Vector2, speed: float = 160) -> void:
	var spec: Dictionary = YinBalance.MONSTERS[record.kind]
	game.world.projectiles.spawn(position + Vector2(0, -4), direction, false, roundi(int(record.get("damage", spec.damage)) * (0.75 if "arm" in record.get("severed", []) else 1.0)) + (2 if record.kind == "archer" else 0), speed, 760, Color("c78882") if record.kind != "lantern" else Color("8bc5b1"))
func volley(pattern: String) -> void:
	var aim: Vector2 = position.direction_to(attack_center)
	match pattern:
		"cold":
			for angle in [-0.18, 0.0, 0.18]: fire_bullet(aim.rotated(angle), 155)
		"fan":
			var count: int = 5 if record.get("elite", false) else 3
			for i in range(count): fire_bullet(aim.rotated((i - (count - 1) / 2.0) * 0.24), 185)
		"tide":
			record.hp = mini(record.max_hp, record.hp + 4)
			for i in range(18): fire_bullet(Vector2.from_angle(TAU * i / 18 + float(record.hp) / record.max_hp), 100 if i % 2 == 0 else 180)
		"opera":
			for i in range(7): fire_bullet(aim.rotated((i - 3) * 0.14), 220)
			burst_remaining = 4 if record.hp < record.max_hp * 0.5 else 2
			burst_timer = 0.2
		"ring", "boss":
			if pattern == "ring": record.hp = mini(record.max_hp, record.hp + 3)
			var count: int = (16 if record.get("elite", false) else 12) if pattern == "ring" else (16 if record.hp < record.max_hp / 2 else 12)
			for i in range(count): fire_bullet(Vector2.from_angle(TAU * i / count + 0.15), 135 if pattern == "ring" else 155)
			if pattern == "boss" and record.hp < record.max_hp * 0.5:
				for angle in [-0.18, 0.0, 0.18]: fire_bullet(aim.rotated(angle), 225)
		"burst":
			burst_remaining = 5 if record.get("elite", false) else 3
			burst_timer = 0

func receive_hit(damage: int, method: String = "sword") -> void:
	if record.dead: return
	var armor: int = int(record.get("armor", 0)) if method not in ["seal", "fire", "bleed"] else 0
	var adjusted: int = YinBalance.damage(damage, 1, {}, armor)
	if record.kind == "boss" and method not in ["seal", "fire", "bleed"]: adjusted = maxi(1, roundi(adjusted * 0.75))
	if shield > 0:
		var absorbed: int = mini(shield, adjusted)
		shield -= absorbed
		adjusted -= absorbed
	var dealt: int = health_receiver.apply(adjusted, method)
	game.world.damage_number(position, dealt, Color("edb779") if method == "fire" else Color("eee0b4"))
	if dealt > 0:
		trail_delay = 0.3
		hit_flash = 0.13
		material.set_shader_parameter("flash", 1.0)
		if method not in ["bleed", "seal"]:
			hit_stop = 0.035 if record.kind in YinAbilities.BOSSES else 0.045
			game.world.impact(position + Vector2(0, -20), game.player.position.direction_to(position), method)
			if method in ["sword", "bullet"]: update_dismemberment()

	if method == "fire":
		record.integrity = maxi(0, record.integrity - 35)
		stun = 0.2
	elif method == "seal":
		record.suppressed = true
		stun = 0.65 if record.kind in YinAbilities.BOSSES else 3
		windup = 0
		burst_remaining = 0
	elif method == "bullet":
		knockback = game.player.position.direction_to(position) * (18 if record.kind in YinAbilities.BOSSES else 42)
		stun = maxf(stun, 0.045)
	elif method == "bleed" or record.kind in YinAbilities.BOSSES:
		pass
	else:
		windup = 0
		stun = maxf(stun, 0.18)
		knockback = (victim.position if is_instance_valid(victim) else game.player.position).direction_to(position) * 75
	if record.hp == 0:
		game.state.kill_enemy(record.id, position)
		game.world.effect(position, Color("97b5a1"))
		game.spawn_remains_visuals()
		game.spawn_pickups()
		game.spawn_gear_pickups()
		game.persist()
		queue_free()

func _draw() -> void:
	if record.is_empty(): return
	draw_rect(Rect2(-12, -3, 24, 5), Color("253b3a66"))
	var row: int = {"water": 0, "bone": 1, "boss": 2, "archer": 3, "lantern": 4, "gunner": 5, "brute": 6, "well_boss": 0, "opera_boss": 5}.get(record.kind, 0)
	var scale_value: float = 3 if record.kind in ["boss", "well_boss", "opera_boss"] else 2
	var tint := Color.WHITE if hit_flash > 0.065 else (Color("d79279") if hit_flash > 0 else (Color("8eafd0") if stun > 0.3 else Color.WHITE))
	var missing: Array = record.get("severed", [])
	# Draw the original sprite in non-overlapping pieces so missing limbs stay absent.
	for part in [Rect2(0, 0, 16, 8), Rect2(4, 8, 8, 10), Rect2(0, 8, 4, 10), Rect2(12, 8, 4, 10), Rect2(0, 18, 8, 6), Rect2(8, 18, 8, 6)]:
		if part.position == Vector2(12, 8) and "arm" in missing: continue
		if part.position == Vector2(8, 18) and "leg" in missing: continue
		var destination := Rect2(Vector2(-8, -22) * scale_value + part.position * scale_value, part.size * scale_value)
		draw_texture_rect_region(TEXTURE, destination, Rect2(part.position + Vector2(0, row * 24), part.size), tint)
	if record.kind == "well_boss":
		draw_arc(Vector2(0, -18), 24, 0, TAU, 16, Color("85c9ce"), 3)
		draw_rect(Rect2(-20, -70, 40, 8), Color("366777"))
	if record.kind == "opera_boss":
		draw_rect(Rect2(-12, -62, 24, 16), Color("e7d6b9"))
		draw_rect(Rect2(-9, -56, 18, 4), Color("9d495c"))
		for side in [-1, 1]: draw_line(Vector2(side * 15, -38), Vector2(side * 31, -7), Color("c26f85"), 4)
	draw_rect(Rect2(-16, -50 * (1.4 if row == 2 else 1), 32, 3), Color("413e3e"))
	draw_rect(Rect2(-16, -50 * (1.4 if row == 2 else 1), 32 * health_trail / record.max_hp, 3), Color("e6bb83"))
	draw_rect(Rect2(-16, -50 * (1.4 if row == 2 else 1), 32 * float(record.hp) / record.max_hp, 3), Color("aa7164"))
	if shield > 0: draw_arc(Vector2(0, -25), 25, 0, TAU, 20, Color("96c0db"), 2)
	if bleed_time > 0: draw_rect(Rect2(-3, -56, 6, 6), Color("b54e5c"))
	var caption: String = YinBalance.MONSTERS[record.kind].name + " Lv%d" % int(record.get("level", 1)) + (" · 精英" if record.get("elite", false) else "")
	draw_string(ThemeDB.fallback_font, Vector2(-24, -56 * (1.4 if row == 2 else 1)), caption, HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color("e6c485") if record.get("elite", false) else Color("c8c9ae"))
	if windup > 0 and YinAbilities.meta(record.kind).pattern in ["fan", "ring", "burst", "tide", "opera", "cold"]:
		var direction: Vector2 = position.direction_to(attack_center)
		draw_line(Vector2(0, -14), direction * 120 - Vector2(0, 14), Color("e0a27b99"), 1)
		draw_arc(Vector2(0, -14), 26, 0, TAU * (1 - windup / 0.85), 24, Color("e6b17c"), 2)
	elif windup > 0:
		var local_center: Vector2 = attack_center - position
		draw_circle(local_center, 57 if row == 2 else (42 if record.kind == "brute" else 29), Color(0.7, 0.27, 0.20, 0.2))
		draw_arc(local_center, 57 if row == 2 else (42 if record.kind == "brute" else 29), -PI / 2, -PI / 2 + TAU * (1 - windup / (0.8 if row == 2 else 0.5)), 32, Color("f0bc7d"), 3)
		draw_rect(Rect2(local_center - Vector2(2, 2), Vector2(4, 4)), Color("f0bc7d"))

func hurt_victim(damage: int) -> void:
	if not is_instance_valid(victim): return
	if "arm" in record.get("severed", []): damage = maxi(1, roundi(damage * 0.75))
	if record.kind == "brute" and record.hp < record.max_hp / 2: damage = roundi(damage * 1.2)
	if victim == game.player: game.take_damage(damage)
	else: victim.receive_hit(damage)
func apply_bleed(duration: float, damage: int) -> void:
	bleed_time = maxf(bleed_time, duration)
	bleed_damage = maxi(bleed_damage, damage)

func update_dismemberment() -> void:
	if not record.has("severed"): record.severed = []
	var ratio: float = float(record.hp) / record.max_hp
	for part in ["arm", "leg"]:
		if part in record.severed or ratio > (0.60 if part == "arm" else 0.30): continue
		record.severed.append(part)
		var fragment := YinSeveredLimb.new()
		fragment.part = part
		fragment.row = {"water": 0, "bone": 1, "boss": 2, "archer": 3, "lantern": 4, "gunner": 5, "brute": 6, "well_boss": 0, "opera_boss": 5}.get(record.kind, 0)
		fragment.sprite_scale = 3.0 if record.kind in YinAbilities.BOSSES else 2.0
		fragment.position = position + Vector2(10, -20 if part == "arm" else -2)
		fragment.velocity = game.player.position.direction_to(position).rotated(-0.6 if part == "arm" else 0.6) * 85
		game.world.feedback.add_child(fragment)
		game.world.effect(fragment.position, Color("a57465"))
