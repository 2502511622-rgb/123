YinGui World modular enemy pack v0.25
All cells: 64 x 64 RGBA, shared 24-color palette, nearest filtering.
Root: (32,61). Left/right refer to the authored unmirrored character.
parts/: body, head, left/right whole arms and legs; no cut-up fragments.
stumps/: four shoulder/thigh overlays plus neck overlay, separate layers.
residual.png: body + head only, no arms or legs.
idle.png: 4 frames; walk.png: 8 frames; hit.png: 3 frames.
blood/: drop, stain and splash; each uses the same 64px cell convention.
atlas.png and manifest.json describe all cells and anatomical pivots.
Animations are baked from the same transforms as the game's modular rig.
Runtime uses separate Sprite2D limbs, not complete-frame substitutions.
Art: generated for this project, then normalized and palette-indexed.
