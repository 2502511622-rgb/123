YinGui World v0.27 / original generated pixel artwork
96x96 transparent cells, 8 columns. Root (48,92).
Four source poses: idle, step A, step B, attack. Walk playback: 0,1,0,2.
Cell frame*6+part; parts: body,head,arm_left,arm_right,leg_left,leg_right.
Cut overlays: 24+frame*5+(part-1). Per-frame pivots in manifest.
Layers partition visible artwork; they do not reconstruct hidden anatomy.
Spectral bodies have no detachable limbs; spider/bird/multiarm use side groups.
No four-direction animation or eight independently drawn walk frames is claimed.
