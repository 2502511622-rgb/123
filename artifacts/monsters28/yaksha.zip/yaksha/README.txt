YinGui World v0.30 / original generated pixel artwork
96x96 transparent cells, 8 columns. Root (48,90).
Six independently authored anatomical parts; one neutral source pose.
Walk: eight interpolated whole-part joint keys; attack: six windup/strike/recovery keys.
Parts overlap at neck, shoulder and hip. Removing a limb never cuts a torso mask.
First six cells: body,head,arm_left,arm_right,leg_left,leg_right.
Cells 6..23 repeat neutral parts only for old saved frame indices; not new drawings.
Cut overlays: 24+frame*5+(part-1). Root (48,90). Pivot metadata included.
Detached whole limbs use the actual animated shoulder/hip transform and rigid physics.
Ghosts float; one-legged yokai have one leg; wings/spider legs use complete side groups.
